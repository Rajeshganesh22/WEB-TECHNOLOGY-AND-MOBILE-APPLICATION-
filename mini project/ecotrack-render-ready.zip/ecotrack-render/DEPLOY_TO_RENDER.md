# Deploy EcoTrack to Render

## Steps

### 1. Push to GitHub
Create a new GitHub repo and push this entire folder:
```bash
git init
git add .
git commit -m "EcoTrack ready for Render"
git remote add origin https://github.com/YOUR_USERNAME/ecotrack.git
git push -u origin main
```

### 2. Create a Render Web Service
1. Go to https://render.com and sign in
2. Click **New → Web Service**
3. Connect your GitHub repo
4. Use these settings:
   - **Root Directory:** `backend`
   - **Build Command:** `npm run build`
   - **Start Command:** `npm start`
   - **Environment:** Node

### 3. Deploy
Click **Create Web Service** — Render will build and deploy automatically.
Your site will be live at: `https://ecotrack.onrender.com` (or similar)

## Default Login Credentials
| Email | Password | Role |
|---|---|---|
| ravi@eco.com | pass123 | Citizen |
| meena@eco.com | pass123 | Citizen |
| admin@eco.com | admin123 | Authority |

## ⚠️ Important Note
Render's free tier uses ephemeral storage — uploaded images and database changes
will reset on each redeploy. For permanent data, upgrade to a paid plan or
switch to a real database (MongoDB Atlas, Supabase, etc.).
